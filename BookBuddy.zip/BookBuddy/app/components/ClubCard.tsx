import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

// Define the structure of Club data
export type Club = {
    id: string;
    name: string;
    description: string;
    memberCount: number;
    currentBook?: string; // Optional current book
    isPrivate: boolean;
    clubCoverUrl: string; // Changed from coverColor
};

interface ClubCardProps {
    club: Club;
    onPress: (club: Club) => void; // Pass the whole club object
    onDelete?: (clubId: string) => void; // Optional delete handler
}

// Add a placeholder URL
const PLACEHOLDER_CLUB_COVER = 'https://via.placeholder.com/300x60/2A1A4B/FFFFFF?text=Club+Banner';

const ClubCard: React.FC<ClubCardProps> = ({ club, onPress, onDelete }) => {
    return (
        <TouchableOpacity style={styles.cardContainer} onPress={() => onPress(club)}>
             <View style={styles.card}>
                {/* Use Image for the banner */}
                <Image
                    source={{ uri: club.clubCoverUrl || PLACEHOLDER_CLUB_COVER }}
                    style={styles.cardBanner}
                    resizeMode="cover"
                />
                <View style={styles.cardContent}>
                    <View style={styles.headerRow}>
                        <Text style={styles.clubName} numberOfLines={1}>{club.name}</Text>
                        {club.isPrivate && (
                            <Ionicons name="lock-closed-outline" size={16} color="#AAA" style={styles.lockIcon} />
                        )}
                    </View>
                    <Text style={styles.description} numberOfLines={2}>{club.description}</Text>
                    <View style={styles.infoRow}>
                        <View style={styles.infoItem}>
                            <Ionicons name="people-outline" size={14} color="#AAA" />
                            <Text style={styles.infoText}>{club.memberCount} Members</Text>
                        </View>
                        {club.currentBook && (
                            <View style={styles.infoItem}>
                                <Ionicons name="book-outline" size={14} color="#AAA" />
                                <Text style={styles.infoText} numberOfLines={1}>{club.currentBook}</Text>
                            </View>
                        )}
                    </View>
                </View>
                {/* Delete Button - Only appears if onDelete is provided */}
                {onDelete && (
                    <TouchableOpacity style={styles.deleteButton} onPress={() => onDelete(club.id)} hitSlop={styles.hitSlop}>
                        <Ionicons name="trash-outline" size={18} color="#FF6B6B" />
                    </TouchableOpacity>
                )}
             </View>
        </TouchableOpacity>
    );
};

const CARD_BG = '#2A1A4B';

const styles = StyleSheet.create({
    cardContainer: {
        marginHorizontal: 24,
        marginBottom: 16,
    },
    card: {
        backgroundColor: CARD_BG,
        borderRadius: 8,
        overflow: 'hidden', // Ensures banner corners are rounded
        position: 'relative', // Needed for absolute positioning of delete button
    },
    cardBanner: {
        height: 60, // Height for the colored banner
        backgroundColor: CARD_BG, // Background while image loads
    },
    cardContent: {
        padding: 12,
    },
    headerRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 4,
    },
    clubName: {
        color: '#FFF',
        fontSize: 16,
        fontWeight: 'bold',
        flexShrink: 1,
        marginRight: 5,
    },
    lockIcon: {
        marginLeft: 'auto',
    },
    description: {
        color: '#CCC',
        fontSize: 14,
        marginBottom: 10,
    },
    infoRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: 10,
    },
    infoItem: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
    },
    infoText: {
        color: '#AAA',
        fontSize: 12,
    },
    deleteButton: {
        position: 'absolute',
        top: 8,
        right: 8,
        padding: 4, // Add padding for easier tapping
        zIndex: 1, // Ensure button is tappable
    },
    hitSlop: { // Increase tappable area for the small delete icon
      top: 10,
      bottom: 10,
      left: 10,
      right: 10,
    },
});

export default ClubCard; 