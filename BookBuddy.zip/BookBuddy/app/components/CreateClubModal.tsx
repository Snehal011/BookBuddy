import React, { useState } from 'react';
import {
    Modal,
    View,
    Text,
    TextInput,
    StyleSheet,
    TouchableOpacity,
    Switch,
    ScrollView,
    Platform,
    FlatList,
    SafeAreaView
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

// Props definition for the modal
interface CreateClubModalProps {
    visible: boolean;
    onClose: () => void;
    onSubmit: (clubData: any) => void; // Replace 'any' with a proper Club type later
}

// --- Constants ---
const DARK = '#1F0B3A';
const CARD_BG = '#2A1A4B';
const INPUT_BG = CARD_BG; // Use CARD_BG for inputs as well
const ACCENT = '#6372FF';
const ACCENT_LIGHT = '#8A94FF';
const TEXT_COLOR = '#FFF';
const LABEL_COLOR = '#CCC';
const PLACEHOLDER_COLOR = '#777';
const BORDER_COLOR = '#444';

// --- Dummy Data ---
const GENRES = ['Fiction', 'Non-Fiction', 'Sci-Fi', 'Fantasy', 'Mystery', 'Thriller', 'Romance'];
const LANGUAGES = ['English', 'Spanish', 'French', 'German', 'Other'];

const CreateClubModal: React.FC<CreateClubModalProps> = ({ visible, onClose, onSubmit }) => {
    // --- State --- 
    const [clubName, setClubName] = useState('');
    const [description, setDescription] = useState('');
    const [selectedGenre, setSelectedGenre] = useState<string | null>(null);
    const [selectedLanguage, setSelectedLanguage] = useState<string>('English');
    const [currentBook, setCurrentBook] = useState('');
    const [isPrivate, setIsPrivate] = useState(false);

    // Picker Modal State
    const [pickerVisible, setPickerVisible] = useState(false);
    const [pickerTitle, setPickerTitle] = useState('');
    const [pickerOptions, setPickerOptions] = useState<string[]>([]);
    const [pickerCallback, setPickerCallback] = useState<(value: string) => void>(() => {});

    // --- Handlers --- 
    const handleSubmit = () => {
        // Basic validation (optional)
        if (!clubName.trim()) {
            alert('Please enter a club name.');
            return;
        }
        if (!description.trim()) {
            alert('Please enter a description.');
            return;
        }
         if (!selectedGenre) {
            alert('Please select a genre.');
            return;
        }

        const clubData = {
            name: clubName,
            description,
            genre: selectedGenre,
            language: selectedLanguage,
            currentBook,
            isPrivate,
        };
        console.log('Submitting Club Data:', clubData);
        onSubmit(clubData); // Pass data back
        // Reset form & close
        setClubName('');
        setDescription('');
        setSelectedGenre(null);
        setSelectedLanguage('English');
        setCurrentBook('');
        setIsPrivate(false);
        onClose(); // Close the main modal
    };

    const handleOpenPicker = (title: string, options: string[], callback: (value: string) => void) => {
        setPickerTitle(title);
        setPickerOptions(options);
        setPickerCallback(() => callback); // Ensure the callback is correctly captured
        setPickerVisible(true);
    };

     const handlePickerSelect = (value: string) => {
        pickerCallback(value); // Execute the stored callback
        setPickerVisible(false);
    };

    // --- Render Functions ---
    const renderPickerInput = (label: string, value: string | null, options: string[], callback: (value: string) => void) => (
        <TouchableOpacity
            style={styles.pickerButton}
            onPress={() => handleOpenPicker(label, options, callback)}
        >
            <Text style={value ? styles.pickerText : styles.pickerPlaceholder}>{value || `Select ${label.toLowerCase()}`}</Text>
            <Ionicons name="chevron-down" size={16} color="#AAA" />
        </TouchableOpacity>
    );

    // --- Main Modal JSX ---
    return (
        <> 
            <Modal
                animationType="slide"
                transparent={true}
                visible={visible}
                onRequestClose={onClose} // For Android back button
            >
                <View style={styles.modalOverlay}>
                    <View style={styles.modalContainer}>
                        <ScrollView showsVerticalScrollIndicator={false}>
                            <View style={styles.modalHeader}>
                                <Text style={styles.modalTitle}>Create New Book Club</Text>
                                <TouchableOpacity onPress={onClose}>
                                    <Ionicons name="close" size={24} color="#AAA" />
                                </TouchableOpacity>
                            </View>

                            {/* Club Name */}
                            <Text style={styles.label}>Club Name</Text>
                            <TextInput
                                style={styles.input}
                                placeholder="Enter club name"
                                placeholderTextColor={PLACEHOLDER_COLOR}
                                value={clubName}
                                onChangeText={setClubName}
                            />

                            {/* Description */}
                            <Text style={styles.label}>Description</Text>
                            <TextInput
                                style={[styles.input, styles.textArea]}
                                placeholder="What is your club about?"
                                placeholderTextColor={PLACEHOLDER_COLOR}
                                value={description}
                                onChangeText={setDescription}
                                multiline
                            />

                            {/* Genre Picker */}
                            <Text style={styles.label}>Genre</Text>
                            {renderPickerInput('Genre', selectedGenre, GENRES, setSelectedGenre)}

                            {/* Language Picker */}
                            <Text style={styles.label}>Language</Text>
                            {renderPickerInput('Language', selectedLanguage, LANGUAGES, setSelectedLanguage)}

                            {/* Current Book */}
                            <Text style={styles.label}>Current Book (Optional)</Text>
                            <TextInput
                                style={styles.input}
                                placeholder="What book is your club reading?"
                                placeholderTextColor={PLACEHOLDER_COLOR}
                                value={currentBook}
                                onChangeText={setCurrentBook}
                            />

                            {/* Private Club Toggle */}
                            <View style={styles.switchRow}>
                                <Text style={styles.labelSwitch}>Private Club</Text>
                                <Switch
                                    trackColor={{ false: '#767577', true: ACCENT_LIGHT }}
                                    thumbColor={isPrivate ? ACCENT : '#f4f3f4'}
                                    ios_backgroundColor="#3e3e3e"
                                    onValueChange={setIsPrivate} // Directly updates state
                                    value={isPrivate} // Reflects state
                                />
                            </View>

                            {/* Action Buttons */}
                            <View style={styles.buttonRow}>
                                <TouchableOpacity style={[styles.button, styles.cancelButton]} onPress={onClose}>
                                    <Text style={[styles.buttonText, styles.cancelButtonText]}>Cancel</Text>
                                </TouchableOpacity>
                                <TouchableOpacity style={[styles.button, styles.createButton]} onPress={handleSubmit}>
                                    <Text style={[styles.buttonText, styles.createButtonText]}>Create Club</Text>
                                </TouchableOpacity>
                            </View>
                        </ScrollView>
                    </View>
                </View>
            </Modal>

            {/* --- Option Picker Modal --- */}
            <Modal
                animationType="slide"
                transparent={true}
                visible={pickerVisible}
                onRequestClose={() => setPickerVisible(false)}
            >
                 <TouchableOpacity 
                    style={styles.pickerOverlay} 
                    activeOpacity={1} 
                    onPressOut={() => setPickerVisible(false)} // Close on press outside
                >
                    <SafeAreaView style={styles.pickerSafeArea}>
                        <View style={styles.pickerContainer}>
                            <View style={styles.pickerHeader}>
                                <Text style={styles.pickerTitle}>{`Select ${pickerTitle}`}</Text>
                                <TouchableOpacity onPress={() => setPickerVisible(false)}>
                                    <Ionicons name="close" size={24} color="#AAA" />
                                </TouchableOpacity>
                            </View>
                            <FlatList
                                data={pickerOptions}
                                keyExtractor={(item) => item}
                                renderItem={({ item }) => (
                                    <TouchableOpacity
                                        style={styles.pickerItem}
                                        onPress={() => handlePickerSelect(item)}
                                    >
                                        <Text style={styles.pickerItemText}>{item}</Text>
                                    </TouchableOpacity>
                                )}
                                ItemSeparatorComponent={() => <View style={styles.pickerSeparator} />}
                            />
                        </View>
                    </SafeAreaView>
                 </TouchableOpacity>
            </Modal>
        </>
    );
};

// --- Styles --- 
const styles = StyleSheet.create({
    // --- Main Modal Styles ---
    modalOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.7)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    modalContainer: {
        backgroundColor: DARK,
        borderRadius: 12,
        padding: 24,
        width: '90%',
        maxHeight: '85%',
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
    },
    modalHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 20,
    },
    modalTitle: {
        color: TEXT_COLOR,
        fontSize: 18,
        fontWeight: 'bold',
    },
    label: {
        color: LABEL_COLOR,
        fontSize: 14,
        marginBottom: 6,
        marginTop: 12,
    },
    labelSwitch: { // Slightly different styling for switch label
        color: LABEL_COLOR,
        fontSize: 14,
    },
    input: {
        backgroundColor: INPUT_BG,
        color: TEXT_COLOR,
        paddingHorizontal: 12,
        paddingVertical: Platform.OS === 'ios' ? 14 : 10,
        borderRadius: 8,
        fontSize: 16,
        borderColor: BORDER_COLOR,
        borderWidth: 1,
        marginBottom: 10,
    },
    textArea: {
        height: 100,
        textAlignVertical: 'top',
    },
    pickerButton: {
        backgroundColor: INPUT_BG,
        paddingHorizontal: 12,
        paddingVertical: Platform.OS === 'ios' ? 14 : 10,
        borderRadius: 8,
        borderColor: BORDER_COLOR,
        borderWidth: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 10,
    },
    pickerText: {
        color: TEXT_COLOR,
        fontSize: 16,
    },
    pickerPlaceholder: {
        color: PLACEHOLDER_COLOR,
        fontSize: 16,
    },
    switchRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginTop: 15,
        marginBottom: 25,
        paddingHorizontal: 4, // Align switch visually
    },
    buttonRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 10,
    },
    button: {
        borderRadius: 8,
        paddingVertical: 14,
        flex: 1,
        alignItems: 'center',
        marginHorizontal: 5,
    },
    cancelButton: {
        backgroundColor: CARD_BG,
        borderColor: BORDER_COLOR,
        borderWidth: 1,
    },
    createButton: {
        backgroundColor: ACCENT,
    },
    buttonText: {
        fontSize: 16,
        fontWeight: '600',
    },
    cancelButtonText: {
        color: '#AAA',
    },
    createButtonText: {
        color: TEXT_COLOR,
    },

    // --- Picker Modal Styles ---
    pickerOverlay: {
        flex: 1,
        justifyContent: 'flex-end', // Position at the bottom
    },
    pickerSafeArea: {
       backgroundColor: CARD_BG, 
       borderTopLeftRadius: 12,
       borderTopRightRadius: 12,
    },
    pickerContainer: {
       maxHeight: '50%', // Limit picker height
    },
    pickerHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 16,
        paddingTop: 16,
        paddingBottom: 8,
        borderBottomWidth: 1,
        borderBottomColor: BORDER_COLOR,
    },
    pickerTitle: {
        color: TEXT_COLOR,
        fontSize: 16,
        fontWeight: 'bold',
    },
    pickerItem: {
        paddingVertical: 15,
        paddingHorizontal: 16,
    },
    pickerItemText: {
        color: TEXT_COLOR,
        fontSize: 16,
    },
    pickerSeparator: {
        height: 1,
        backgroundColor: BORDER_COLOR,
        marginHorizontal: 16,
    },
});

export default CreateClubModal; 