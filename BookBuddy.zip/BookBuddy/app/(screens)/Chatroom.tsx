import React, { useState, useRef, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    SafeAreaView,
    TouchableOpacity,
    TextInput,
    FlatList,
    KeyboardAvoidingView,
    Platform,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

// --- Types --- 
interface Message {
    id: string;
    text: string;
    sender: 'me' | 'other'; // Simple sender type for styling
    timestamp: number;
}

// --- Dummy Data --- 
const INITIAL_MESSAGES: Message[] = [
    { id: 'm1', text: 'Hey everyone! Excited to discuss Dune!', sender: 'other', timestamp: Date.now() - 60000 * 5 },
    { id: 'm2', text: 'Me too! Just finished rereading the first part.', sender: 'me', timestamp: Date.now() - 60000 * 4 },
    { id: 'm3', text: 'What did you think of the political intrigue?', sender: 'other', timestamp: Date.now() - 60000 * 3 },
    { id: 'm4', text: 'Loved it! Complex but rewarding.', sender: 'me', timestamp: Date.now() - 60000 * 2 },
];
// --------------- 

const ChatroomScreen = () => {
    const { clubId, clubName } = useLocalSearchParams<{ clubId: string; clubName: string }>();
    const router = useRouter();
    const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
    const [newMessage, setNewMessage] = useState('');
    const flatListRef = useRef<FlatList>(null);

    // Scroll to bottom when messages change
    useEffect(() => {
        flatListRef.current?.scrollToEnd({ animated: true });
    }, [messages]);

    const handleSend = () => {
        if (newMessage.trim() === '') return; // Don't send empty messages

        const messageToSend: Message = {
            id: `m${Date.now()}`,
            text: newMessage.trim(),
            sender: 'me', // Assume message sent is always from 'me'
            timestamp: Date.now(),
        };

        setMessages(prevMessages => [...prevMessages, messageToSend]);
        setNewMessage(''); // Clear input
    };

    const renderMessageItem = ({ item }: { item: Message }) => (
        <View
            style={[
                styles.messageBubble,
                item.sender === 'me' ? styles.myMessage : styles.otherMessage,
            ]}
        >
            <Text style={styles.messageText}>{item.text}</Text>
            {/* Optional: Add timestamp display */}
            {/* <Text style={styles.timestamp}>{new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</Text> */}
        </View>
    );

    return (
        <SafeAreaView style={styles.safeArea}>
            {/* Header */}
            <View style={styles.header}>
                 <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
                     <Ionicons name="chevron-back" size={28} color="#FFF" />
                 </TouchableOpacity>
                <Text style={styles.headerTitle} numberOfLines={1}>{clubName || 'Chatroom'}</Text>
                 <View style={styles.headerRightPlaceholder} />
            </View>

            <KeyboardAvoidingView
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                style={styles.keyboardAvoidingContainer}
                keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0} // Adjust offset as needed
            >
                {/* Message List */}
                <FlatList
                    ref={flatListRef}
                    data={messages}
                    renderItem={renderMessageItem}
                    keyExtractor={item => item.id}
                    style={styles.messageList}
                    contentContainerStyle={styles.messageListContent}
                    // onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: false })} // Alternative scroll method
                    // onLayout={() => flatListRef.current?.scrollToEnd({ animated: false })} // Alternative scroll method
                />

                {/* Input Area */}
                <View style={styles.inputContainer}>
                    <TextInput
                        style={styles.input}
                        placeholder="Type your message..."
                        placeholderTextColor="#AAA"
                        value={newMessage}
                        onChangeText={setNewMessage}
                        multiline
                    />
                    <TouchableOpacity style={styles.sendButton} onPress={handleSend} disabled={!newMessage.trim()}>
                         <Ionicons
                             name="send"
                             size={22}
                             color={newMessage.trim() ? '#FFF' : '#555'} // Dim button when disabled
                         />
                    </TouchableOpacity>
                </View>
            </KeyboardAvoidingView>
        </SafeAreaView>
    );
};

// --- Styles --- 
const DARK = '#1F0B3A';
const CARD_BG = '#2A1A4B';
const ACCENT = '#6372FF';
const MY_MESSAGE_BG = ACCENT;
const OTHER_MESSAGE_BG = CARD_BG;

const styles = StyleSheet.create({
    safeArea: { flex: 1, backgroundColor: DARK },
    keyboardAvoidingContainer: {
        flex: 1,
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingVertical: 10,
        paddingHorizontal: 10,
        borderBottomWidth: 1,
        borderBottomColor: CARD_BG,
    },
    backButton: { padding: 5 },
    headerTitle: {
        color: '#FFF',
        fontSize: 18,
        fontWeight: 'bold',
        textAlign: 'center',
        flex: 1,
        marginHorizontal: 10,
    },
    headerRightPlaceholder: { width: 38 },
    messageList: {
        flex: 1,
    },
    messageListContent: {
        paddingVertical: 10,
        paddingHorizontal: 10,
    },
    messageBubble: {
        paddingVertical: 8,
        paddingHorizontal: 12,
        borderRadius: 18,
        marginBottom: 8,
        maxWidth: '80%', // Limit message width
    },
    myMessage: {
        backgroundColor: MY_MESSAGE_BG,
        alignSelf: 'flex-end', // Align to the right
    },
    otherMessage: {
        backgroundColor: OTHER_MESSAGE_BG,
        alignSelf: 'flex-start', // Align to the left
    },
    messageText: {
        color: '#FFF',
        fontSize: 15,
    },
    // Optional timestamp style
    // timestamp: {
    //     color: '#CCC',
    //     fontSize: 10,
    //     alignSelf: 'flex-end',
    //     marginTop: 2,
    // },
    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 10,
        paddingVertical: 8,
        borderTopWidth: 1,
        borderTopColor: CARD_BG,
        backgroundColor: DARK, // Match safe area background
    },
    input: {
        flex: 1,
        backgroundColor: CARD_BG,
        color: '#FFF',
        borderRadius: 20, // Rounded input
        paddingHorizontal: 15,
        paddingVertical: Platform.OS === 'ios' ? 10 : 8,
        paddingTop: Platform.OS === 'ios' ? 10 : 8, // Fix paddingTop for multiline on Android
        fontSize: 15,
        maxHeight: 100, // Limit input height
        marginRight: 10,
    },
    sendButton: {
        padding: 8,
        borderRadius: 25,
        backgroundColor: ACCENT,
    },
});

export default ChatroomScreen; 