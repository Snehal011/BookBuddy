import React, { useEffect } from 'react';
import { View, StyleSheet, Text } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

const SplashScreen = () => {
    const router = useRouter();

    useEffect(() => {
        // Simulate loading time
        const timer = setTimeout(() => {
            router.push('/(screens)/AuthScreen');
        }, 2000);

        return () => clearTimeout(timer);
    }, []);

    return (
        <View style={styles.container}>
            <Ionicons name="book-outline" size={100} color="#FFF" />
            <Text style={styles.logoText}>BookBuddy</Text>
        </View>
    );
};

const DARK = '#1F0B3A';

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: DARK,
        justifyContent: 'center',
        alignItems: 'center',
    },
    logoText: {
        color: '#FFF',
        fontSize: 32,
        fontWeight: 'bold',
        marginTop: 15,
    },
});

export default SplashScreen; 