// src/screens/HomeScreen.tsx
import React from 'react';
import {
    View,
    Text,
    FlatList,
    TouchableOpacity,
    StyleSheet,
    Dimensions,
    Image
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';

const { width } = Dimensions.get('window');
const CARD_WIDTH = (width - 48) / 2;

type Book = {
    id: string;
    title: string;
    author: string;
    coverUrl: string;
    progress: number;
};

// Placeholder URL - User will provide specific URLs
const PLACEHOLDER_IMAGE_URL = 'https://via.placeholder.com/150/2A1A4B/FFFFFF?text=Book+Cover';

const CONTINUE_READING: Book[] = [
    {
        id: '1',
        title: 'The Midnight Library',
        author: 'Matt Haig',
        coverUrl: '', // Empty URL, user will provide
        progress: 45,
    },
    {
        id: '2',
        title: 'Atomic Habits',
        author: 'James Clear',
        coverUrl: '', // Empty URL, user will provide
        progress: 72,
    },
];

const TRENDING_BOOK_URL = ''; // Empty URL for trending book

const HomeScreen = () => {
    const router = useRouter();

    return (
        <SafeAreaView style={styles.safe}>
            <View style={styles.header}>
                <Text style={styles.logo}>BookBuddy</Text>
                <TouchableOpacity style={styles.avatar} onPress={() => router.push('/(tabs)/Profile')}>
                    <Text style={styles.avatarText}>S</Text>
                </TouchableOpacity>
            </View>

            <Text style={styles.greeting}>Good Evening, snehal!</Text>

            <View style={styles.sectionHeader}>
                <View style={styles.sectionTitle}>
                    <Ionicons name="book-outline" size={20} color="#FFF" />
                    <Text style={styles.sectionText}>Continue Reading</Text>
                </View>
                <TouchableOpacity onPress={() => router.push('/(tabs)/Discover')}>
                    <Text style={styles.seeAll}>See all</Text>
                </TouchableOpacity>
            </View>

            <FlatList
                data={CONTINUE_READING}
                keyExtractor={b => b.id}
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={{ paddingLeft: 24, paddingVertical: 10 }}
                renderItem={({ item }) => (
                    <TouchableOpacity style={styles.card}>
                        <Image
                            source={{ uri: item.coverUrl || PLACEHOLDER_IMAGE_URL }}
                            style={styles.cover}
                            resizeMode="cover"
                        />
                        <Text numberOfLines={1} style={styles.bookTitle}>
                            {item.title}
                        </Text>
                        <Text style={styles.bookAuthor}>{item.author}</Text>
                    </TouchableOpacity>
                )}
            />

            <View style={styles.trendingHeader}>
                <Ionicons name="trending-up-outline" size={20} color="#FFF" />
                <Text style={styles.sectionText}>Trending Now</Text>
            </View>

            <View style={styles.trendingCard}>
                <Image
                    source={{ uri: TRENDING_BOOK_URL || PLACEHOLDER_IMAGE_URL }}
                    style={styles.trendingCover}
                    resizeMode="cover"
                />
                <View style={styles.trendingInfo}>
                    <Text numberOfLines={1} style={styles.trendingTitle}>
                        Tomorrow, and Tomorrow, and Tomorrow
                    </Text>
                    <Text style={styles.trendingAuthor}>Gabrielle Zevin</Text>
                </View>
            </View>
        </SafeAreaView>
    );
};

export default HomeScreen;

const DARK = '#1F0B3A';
const CARD_BG = '#2A1A4B';
const ACCENT = '#6372FF';

const styles = StyleSheet.create({
    safe: { flex: 1, backgroundColor: DARK },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 24,
        paddingBottom: 10,
    },
    logo: { color: '#FFF', fontSize: 24, fontWeight: 'bold' },
    avatar: {
        width: 36,
        height: 36,
        borderRadius: 18,
        backgroundColor: ACCENT,
        alignItems: 'center',
        justifyContent: 'center',
    },
    avatarText: { color: '#FFF', fontWeight: '600' },

    greeting: {
        color: '#CCC',
        fontSize: 16,
        marginHorizontal: 24,
        marginBottom: 16,
    },

    sectionHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginHorizontal: 24,
        marginBottom: 10,
    },
    sectionTitle: { flexDirection: 'row', alignItems: 'center' },
    sectionText: { color: '#FFF', fontSize: 18, marginLeft: 8, fontWeight: '600' },
    seeAll: { color: ACCENT, fontSize: 14 },

    card: {
        width: CARD_WIDTH,
        marginRight: 16,
    },
    cover: {
        width: '100%',
        height: CARD_WIDTH * 1.4,
        borderRadius: 8,
        backgroundColor: CARD_BG,
    },
    bookTitle: { color: '#FFF', fontWeight: '600', marginTop: 8 },
    bookAuthor: { color: '#AAA', fontSize: 12 },

    trendingHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 24,
        marginHorizontal: 24,
        marginBottom: 10,
    },

    trendingCard: {
        flexDirection: 'row',
        backgroundColor: CARD_BG,
        borderRadius: 8,
        marginHorizontal: 24,
        marginTop: 10,
        overflow: 'hidden',
    },
    trendingCover: {
        width: 80,
        height: 120,
        backgroundColor: CARD_BG,
    },
    trendingInfo: {
        flex: 1,
        padding: 12,
        justifyContent: 'center',
    },
    trendingTitle: { color: '#FFF', fontWeight: '600' },
    trendingAuthor: { color: '#AAA', fontSize: 12, marginTop: 4 },
}); 