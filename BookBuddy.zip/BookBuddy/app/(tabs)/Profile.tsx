import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    SafeAreaView,
    TouchableOpacity,
    ScrollView,
    TextInput,
    Platform
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

// Dummy User Data
const USER_DATA = {
    name: 'Snehal Patel', // Replace with actual data source
    email: 'snehal.p@example.com',
    joinDate: '2024-01-15',
    favoriteGenre: 'Fantasy',
    location: 'Mumbai, India'
};

const ProfileScreen = () => {
    const [isEditing, setIsEditing] = useState(false);
    // State for all fields
    const [name, setName] = useState(USER_DATA.name);
    const [email, setEmail] = useState(USER_DATA.email);
    const [joinDateString, setJoinDateString] = useState(new Date(USER_DATA.joinDate).toLocaleDateString());
    const [location, setLocation] = useState(USER_DATA.location);
    const [favoriteGenre, setFavoriteGenre] = useState(USER_DATA.favoriteGenre);
    // Keep original data to revert on cancel
    const [originalData, setOriginalData] = useState({ 
        ...USER_DATA, 
        joinDateString: new Date(USER_DATA.joinDate).toLocaleDateString() 
    });

    // Update editable fields if USER_DATA changes (e.g., fetched from API)
    useEffect(() => {
        setName(USER_DATA.name);
        setEmail(USER_DATA.email);
        setJoinDateString(new Date(USER_DATA.joinDate).toLocaleDateString());
        setLocation(USER_DATA.location);
        setFavoriteGenre(USER_DATA.favoriteGenre);
        setOriginalData({ 
            ...USER_DATA, 
            joinDateString: new Date(USER_DATA.joinDate).toLocaleDateString() 
        });
    }, []); // Add dependency if USER_DATA can change after mount

    const handleLogout = () => {
        // Add logout logic here (e.g., clear auth state, navigate to AuthScreen)
        console.log('Logout Pressed');
        // Example navigation (replace with your actual logic):
        // import { useRouter } from 'expo-router';
        // const router = useRouter();
        // router.replace('/(screens)/AuthScreen');
        alert('Logout functionality not implemented yet.');
    };

    const handleEditToggle = () => {
        if (isEditing) { // Save Action
            // Add save logic here (e.g., API call)
            // NOTE: Saving email/joinDate might require extra validation/logic
            const updatedData = { name, email, joinDate: joinDateString, location, favoriteGenre };
            console.log('Saving Profile:', updatedData);
            // Update original data on successful save
            setOriginalData({ ...originalData, ...updatedData, joinDate: USER_DATA.joinDate /* keep original date object */ });
            setIsEditing(false);
        } else { // Start Editing
             setIsEditing(true);
        }
    };

    const handleCancelEdit = () => {
        // Revert changes
        setName(originalData.name);
        setEmail(originalData.email);
        setJoinDateString(originalData.joinDateString);
        setLocation(originalData.location);
        setFavoriteGenre(originalData.favoriteGenre);
        setIsEditing(false);
    };

    // Updated renderInfoRow to handle editable flag
    const renderInfoRow = (icon: keyof typeof Ionicons.glyphMap, label: string, value: string | undefined, editable = false, onChangeText?: (text: string) => void, keyboardType: 'default' | 'email-address' = 'default') => (
        <View style={[styles.infoRow, !isEditing && !value && styles.infoRowEmpty]}>
            <Ionicons name={icon} size={20} color={ACCENT} style={styles.infoIcon} />
            <View style={styles.infoTextContainer}>
                <Text style={styles.infoLabel}>{label}</Text>
                {isEditing && editable ? (
                    <TextInput
                        style={styles.infoInput}
                        value={value}
                        onChangeText={onChangeText}
                        placeholder={`Enter ${label.toLowerCase()}`}
                        placeholderTextColor="#666"
                        keyboardType={keyboardType}
                        autoCapitalize={keyboardType === 'email-address' ? 'none' : 'words'}
                    />
                ) : (
                    <Text style={styles.infoValue}>{value || 'Not specified'}</Text>
                )}
            </View>
        </View>
    );

    return (
        <SafeAreaView style={styles.safeArea}>
            <ScrollView contentContainerStyle={styles.container}>
                {/* Header */}
                <Text style={styles.headerTitle}>Profile</Text>

                {/* Avatar Placeholder */}
                <View style={styles.avatarContainer}>
                    <View style={styles.avatarPlaceholder}>
                        <Ionicons name="person-sharp" size={60} color={DARK} />
                    </View>
                    {/* Display Name or Input */}
                    {isEditing ? (
                         <TextInput
                            style={[styles.userNameInput, styles.infoInput]} 
                            value={name}
                            onChangeText={setName}
                            placeholder="Enter name"
                            placeholderTextColor="#666"
                         />
                    ) : (
                        <Text style={styles.userName}>{name}</Text>
                    )}
                </View>

                {/* User Details Section */}
                <View style={styles.detailsSection}>
                    {/* Make all fields editable */} 
                    {renderInfoRow('mail-outline', 'Email', email, true, setEmail, 'email-address')}
                    {renderInfoRow('calendar-outline', 'Joined On', joinDateString, true, setJoinDateString)}
                    {renderInfoRow('heart-outline', 'Favorite Genre', favoriteGenre, true, setFavoriteGenre)}
                    {renderInfoRow('location-outline', 'Location', location, true, setLocation)}
                </View>

                {/* Action Buttons */}
                {isEditing ? (
                    <View style={styles.editActionsContainer}>
                         <TouchableOpacity style={[styles.actionButton, styles.cancelButton]} onPress={handleCancelEdit}>
                            <Ionicons name="close-circle-outline" size={20} color="#FF6B6B" />
                            <Text style={[styles.actionButtonText, styles.cancelButtonText]}>Cancel</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={[styles.actionButton, styles.saveButton]} onPress={handleEditToggle}>
                            <Ionicons name="checkmark-circle-outline" size={20} color="#FFF" />
                            <Text style={styles.actionButtonText}>Save</Text>
                        </TouchableOpacity>
                    </View>
                ) : (
                    <TouchableOpacity style={[styles.actionButton, styles.editButton]} onPress={handleEditToggle}>
                        <Ionicons name="pencil-outline" size={20} color="#FFF" />
                        <Text style={styles.actionButtonText}>Edit Profile</Text>
                    </TouchableOpacity>
                )}

                {/* Logout Button - Only show when not editing */}
                 {!isEditing && (
                    <TouchableOpacity style={[styles.actionButton, styles.logoutButton]} onPress={handleLogout}>
                        <Ionicons name="log-out-outline" size={20} color="#FF6B6B" />
                        <Text style={[styles.actionButtonText, styles.logoutButtonText]}>Logout</Text>
                    </TouchableOpacity>
                 )}

            </ScrollView>
        </SafeAreaView>
    );
};

// --- Styles (Added infoRowEmpty) ---
const DARK = '#1F0B3A';
const CARD_BG = '#2A1A4B';
const ACCENT = '#6372FF';
const ACCENT_LIGHT = '#8A94FF';
const INPUT_BG = '#3a2a5b'; // Slightly different background for input

const styles = StyleSheet.create({
    safeArea: { flex: 1, backgroundColor: DARK },
    container: { flexGrow: 1, paddingVertical: 20, paddingHorizontal: 24 },
    headerTitle: { color: '#FFF', fontSize: 24, fontWeight: 'bold', textAlign: 'center', marginBottom: 30 },
    avatarContainer: { alignItems: 'center', marginBottom: 30 },
    avatarPlaceholder: { width: 100, height: 100, borderRadius: 50, backgroundColor: ACCENT_LIGHT, justifyContent: 'center', alignItems: 'center', marginBottom: 15 },
    userName: { color: '#FFF', fontSize: 20, fontWeight: 'bold' },
    userNameInput: { // Style for editing username
        fontSize: 20,
        fontWeight: 'bold',
        borderBottomWidth: 1,
        borderColor: ACCENT,
        paddingBottom: 2,
        textAlign: 'center',
        minWidth: 150, // Give some width
        color: '#FFF', // Ensure text color is white
        paddingVertical: Platform.OS === 'ios' ? 4 : 0, 
        margin: 0, 
        backgroundColor: INPUT_BG,
        borderRadius: 4,
        paddingHorizontal: 6,
    },
    detailsSection: { backgroundColor: CARD_BG, borderRadius: 8, paddingVertical: 10, paddingHorizontal: 15, marginBottom: 30 },
    infoRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#3a2a5b' },
    infoRowEmpty: { opacity: 0.6 }, // Style for empty non-editable fields
    infoRowLast: { borderBottomWidth: 0 }, // Apply this manually to the last row if needed
    infoIcon: { marginRight: 15 },
    infoTextContainer: { flex: 1 },
    infoLabel: { color: '#AAA', fontSize: 13, marginBottom: 2 },
    infoValue: { color: '#FFF', fontSize: 16 },
    infoInput: { // Style for editable text inputs in rows
        color: '#FFF',
        fontSize: 16,
        paddingVertical: Platform.OS === 'ios' ? 4 : 0, 
        margin: 0, 
        backgroundColor: INPUT_BG,
        borderRadius: 4,
        paddingHorizontal: 6,
    },
     actionButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 14, borderRadius: 8, gap: 10, marginBottom: 15 },
    editButton: { backgroundColor: ACCENT },
    logoutButton: { backgroundColor: 'transparent', borderColor: '#FF6B6B', borderWidth: 1 },
    actionButtonText: { color: '#FFF', fontSize: 16, fontWeight: '600' },
    logoutButtonText: { color: '#FF6B6B' },
    // Edit Mode Buttons
     editActionsContainer: { // Container for Save/Cancel
        flexDirection: 'row',
        justifyContent: 'space-between',
        gap: 15,
        marginBottom: 15,
    },
     saveButton: {
        backgroundColor: ACCENT,
        flex: 1, // Make buttons equal width
    },
    cancelButton: {
        backgroundColor: 'transparent',
        borderColor: '#FF6B6B',
        borderWidth: 1,
        flex: 1, // Make buttons equal width
    },
    cancelButtonText: {
        color: '#FF6B6B',
    },
});

export default ProfileScreen; 