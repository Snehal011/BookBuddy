import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TextInput,
    SafeAreaView,
    FlatList,
    TouchableOpacity,
    Dimensions,
    ScrollView,
    Image
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const { width } = Dimensions.get('window');
const GENRE_CHIP_WIDTH = (width - 48 - 32) / 3.5; // Adjust spacing and number visible
const BOOK_CARD_WIDTH = (width - 48 - 16) / 2; // 2 columns with spacing

const GENRES = [
    'All', 'Fiction', 'Non-Fiction', 'Sci-Fi', 'Fantasy', 'Mystery', 'Thriller', 'Romance'
];

// Add placeholder URL back
const PLACEHOLDER_IMAGE_URL = 'https://via.placeholder.com/150/2A1A4B/FFFFFF?text=Book+Cover';

type DummyBook = {
    id: string;
    title: string;
    author: string;
    coverUrl: string; // Using URL again
};

// Reduced dummy book list using URLs
const DUMMY_BOOKS: DummyBook[] = [
    { id: 'b1', title: 'Project Hail Mary', author: 'Andy Weir', coverUrl: 'https://covers.openlibrary.org/b/olid/OL31602318M-L.jpg' },
    { id: 'b2', title: 'Klara and the Sun', author: 'Kazuo Ishiguro', coverUrl: 'https://covers.openlibrary.org/b/olid/OL31012435M-L.jpg' },
    { id: 'b3', title: 'The Invisible Life of Addie LaRue', author: 'V.E. Schwab', coverUrl: 'https://covers.openlibrary.org/b/olid/OL28819067M-L.jpg' },
    { id: 'b4', title: 'Fourth Wing', author: 'Rebecca Yarros', coverUrl: 'https://covers.openlibrary.org/b/olid/OL42988085M-L.jpg' },
];

const DiscoverScreen = () => {
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedGenre, setSelectedGenre] = useState('All');

    // --- Helper Functions (Placeholder) ---
    const handleSearch = () => {
        console.log('Search:', searchQuery);
        // Add actual search logic here
    };

    const renderGenreChip = ({ item }: { item: string }) => (
        <TouchableOpacity
            style={[
                styles.genreChip,
                selectedGenre === item && styles.genreChipActive
            ]}
            onPress={() => setSelectedGenre(item)}
        >
            <Text style={[styles.genreText, selectedGenre === item && styles.genreTextActive]}>
                {item}
            </Text>
        </TouchableOpacity>
    );

    const renderBookCard = ({ item }: { item: DummyBook }) => (
        <TouchableOpacity style={styles.bookCard}>
            <Image
                source={{ uri: item.coverUrl || PLACEHOLDER_IMAGE_URL }} // Use URI
                style={styles.bookCover}
                resizeMode="cover"
            />
            <Text style={styles.bookTitle} numberOfLines={2}>{item.title}</Text>
            <Text style={styles.bookAuthor} numberOfLines={1}>{item.author}</Text>
        </TouchableOpacity>
    );
    // -----------------------------------------

    return (
        <SafeAreaView style={styles.safeArea}>
            <ScrollView style={styles.container} stickyHeaderIndices={[1]}> 
                 {/* Header */}
                <Text style={styles.headerTitle}>Discover</Text>

                {/* Search Bar (Sticky) */}
                 <View style={styles.stickyHeaderBackground}> 
                    <View style={styles.searchContainer}>
                        <Ionicons name="search-outline" size={20} color="#AAA" style={styles.searchIcon} />
                        <TextInput
                            style={styles.searchInput}
                            placeholder="Search books, authors, genres..."
                            placeholderTextColor="#AAA"
                            value={searchQuery}
                            onChangeText={setSearchQuery}
                            onSubmitEditing={handleSearch} // Trigger search on submit
                            returnKeyType="search"
                        />
                    </View>
                 </View> 

                 {/* Genre Filter */}
                <View style={styles.genreContainer}>
                    <Text style={styles.sectionTitle}>Genres</Text>
                    <FlatList
                        data={GENRES}
                        renderItem={renderGenreChip}
                        keyExtractor={(item) => item}
                        horizontal
                        showsHorizontalScrollIndicator={false}
                        contentContainerStyle={styles.genreListContent}
                    />
                </View>

                {/* Book List */}
                <View style={styles.bookListContainer}>
                    <Text style={styles.sectionTitle}>Featured Books</Text>
                    <FlatList
                        data={DUMMY_BOOKS} // Filter this based on selectedGenre in real app
                        renderItem={renderBookCard}
                        keyExtractor={(item) => item.id}
                        numColumns={2}
                        columnWrapperStyle={styles.bookListColumnWrapper}
                        scrollEnabled={false} // Disable scroll for inner FlatList
                    />
                </View>
            </ScrollView>
        </SafeAreaView>
    );
};

const DARK = '#1F0B3A';
const CARD_BG = '#2A1A4B';
const ACCENT = '#6372FF';

const styles = StyleSheet.create({
    safeArea: {
        flex: 1,
        backgroundColor: DARK,
    },
    container: {
        flex: 1,
    },
    stickyHeaderBackground: { // Added for sticky header styling
        backgroundColor: DARK, // Match screen background
        paddingBottom: 10, // Space below search
    },
    headerTitle: {
        color: '#FFF',
        fontSize: 24,
        fontWeight: 'bold',
        textAlign: 'center',
        marginTop: 20, // Adjusted from paddingTop
        marginBottom: 20,
        paddingHorizontal: 24,
    },
    searchContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: CARD_BG,
        borderRadius: 8,
        marginHorizontal: 24,
        // marginBottom: 20, // Removed, spacing handled by stickyHeaderBackground
        paddingHorizontal: 12,
    },
    searchIcon: {
        marginRight: 8,
    },
    searchInput: {
        flex: 1,
        color: '#FFF',
        paddingVertical: 12,
        fontSize: 16,
    },
    sectionTitle: {
        color: '#FFF',
        fontSize: 18,
        fontWeight: '600',
        marginBottom: 12,
        paddingHorizontal: 24,
    },
    genreContainer: {
        marginTop: 10, // Space above genres
        marginBottom: 20,
    },
    genreListContent: {
        paddingHorizontal: 24,
        gap: 8, // Spacing between chips
    },
    genreChip: {
        backgroundColor: CARD_BG,
        paddingVertical: 8,
        paddingHorizontal: 16,
        borderRadius: 16,
        // minWidth: GENRE_CHIP_WIDTH, // Removed for variable width
        alignItems: 'center',
        justifyContent: 'center',
    },
    genreChipActive: {
        backgroundColor: ACCENT,
    },
    genreText: {
        color: '#AAA',
        fontWeight: '600',
        fontSize: 14,
    },
    genreTextActive: {
        color: '#FFF',
    },
    bookListContainer: {
        paddingHorizontal: 24,
        paddingBottom: 24, // Space at the bottom
    },
    bookListColumnWrapper: {
        justifyContent: 'space-between',
        marginBottom: 16, // Space between rows
    },
    bookCard: {
        width: BOOK_CARD_WIDTH,
    },
    bookCover: {
        width: '100%',
        height: BOOK_CARD_WIDTH * 1.4, // Aspect ratio
        borderRadius: 8,
        marginBottom: 8,
        backgroundColor: CARD_BG, // Background while image loads
    },
    bookTitle: {
        color: '#FFF',
        fontWeight: '600',
        fontSize: 14,
        marginBottom: 2,
    },
    bookAuthor: {
        color: '#AAA',
        fontSize: 12,
    },
    // --- Removed Unused Styles ---
    // contentArea: { ... }
    // placeholderView: { ... }
    // placeholderText: { ... }
    // placeholderSubText: { ... }
});

export default DiscoverScreen; 