import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    SafeAreaView,
    FlatList,
    Alert
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import CreateClubModal from '../components/CreateClubModal';
import ClubCard, { Club } from '../components/ClubCard';

// --- Dummy Data (Reduced & Updated with coverUrl) ---
const INITIAL_YOUR_CLUBS: Club[] = [
    { 
        id: 'yc1', 
        name: 'My Fantasy Readers', 
        description: 'Discussing the latest epic fantasy novels.', 
        memberCount: 15, 
        currentBook: 'Fourth Wing', 
        isPrivate: false, 
        clubCoverUrl: 'https://images.unsplash.com/photo-1516979187457-637abb4f9353?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Ym9va3N8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60' // Example URL
    },
];

const INITIAL_ALL_CLUBS: Club[] = [
    { 
        id: 'ac1', 
        name: 'Cozy Mystery Corner', 
        description: 'Solving fictional crimes together!', 
        memberCount: 25, 
        currentBook: 'The Thursday Murder Club', 
        isPrivate: false, 
        clubCoverUrl: 'https://images.unsplash.com/photo-1551029506-0807df4e2031?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8Ym9va3N8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60' // Example URL
    },
    { 
        id: 'ac3', 
        name: 'Non-Fiction Nerds', 
        description: 'Learning something new every month.', 
        memberCount: 18, 
        currentBook: 'Sapiens', 
        isPrivate: false, 
        clubCoverUrl: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fGJvb2tzfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60' // Example URL
    },
    ...INITIAL_YOUR_CLUBS 
].filter((club, index, self) =>
    index === self.findIndex((c) => c.id === club.id)
);
// ----------------------------------------------------

const ClubScreen = () => {
    const [selectedTab, setSelectedTab] = useState<'all' | 'your'>('all');
    const [isModalVisible, setIsModalVisible] = useState(false);
    const [yourClubs, setYourClubs] = useState<Club[]>(INITIAL_YOUR_CLUBS);
    const [allClubs, setAllClubs] = useState<Club[]>(INITIAL_ALL_CLUBS);
    const router = useRouter();

    const handleCreateClubPress = () => {
        setIsModalVisible(true);
    };

    const handleModalClose = () => {
        setIsModalVisible(false);
    };

    const handleModalSubmit = (clubData: Omit<Club, 'id' | 'memberCount' | 'clubCoverUrl'>) => {
        const newClub: Club = {
            ...clubData,
            id: `yc${Date.now()}`,
            memberCount: 1,
            // Assign a placeholder cover URL for newly created clubs
            clubCoverUrl: `https://via.placeholder.com/300x60/${ACCENT.substring(1)}/FFFFFF?text=${encodeURIComponent(clubData.name)}` 
        };
        setYourClubs(prevClubs => [newClub, ...prevClubs]);
        if (!newClub.isPrivate) {
             setAllClubs(prevClubs => [newClub, ...prevClubs]);
        }
        setIsModalVisible(false);
    };

    const handleDeleteClub = (clubIdToDelete: string) => {
        Alert.alert(
            "Delete Club",
            "Are you sure you want to delete this club?",
            [
                { text: "Cancel", style: "cancel" },
                {
                    text: "Delete",
                    style: "destructive",
                    onPress: () => {
                        setYourClubs(prevClubs => prevClubs.filter(club => club.id !== clubIdToDelete));
                        setAllClubs(prevClubs => prevClubs.filter(club => club.id !== clubIdToDelete));
                    }
                }
            ]
        );
    };

    const handleClubPress = (club: Club) => {
        console.log('Navigating to chat for club:', club.name);
        router.push({ 
            pathname: '/(screens)/Chatroom',
            params: { clubId: club.id, clubName: club.name }
        });
    };

    const renderListEmpty = () => (
        <View style={styles.placeholderViewEmptyList}>
            <Ionicons name="sad-outline" size={50} color="#555" />
            <Text style={styles.placeholderText}>No clubs found.</Text>
        </View>
    );

    return (
        <SafeAreaView style={styles.safeArea}>
            <View style={styles.container}>
                <Text style={styles.headerTitle}>Clubs</Text>

                {/* Segmented Control */}
                <View style={styles.segmentContainer}>
                    <TouchableOpacity
                        style={[
                            styles.segmentButton,
                            selectedTab === 'all' && styles.segmentButtonActive,
                        ]}
                        onPress={() => setSelectedTab('all')}
                    >
                        <Ionicons name="globe-outline" size={20} color={selectedTab === 'all' ? '#FFF' : '#AAA'} />
                        <Text style={[styles.segmentText, selectedTab === 'all' && styles.segmentTextActive]}>All Clubs</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={[
                            styles.segmentButton,
                            selectedTab === 'your' && styles.segmentButtonActive,
                        ]}
                        onPress={() => setSelectedTab('your')}
                    >
                        <Ionicons name="person-outline" size={20} color={selectedTab === 'your' ? '#FFF' : '#AAA'} />
                        <Text style={[styles.segmentText, selectedTab === 'your' && styles.segmentTextActive]}>Your Clubs</Text>
                    </TouchableOpacity>
                </View>

                {/* Content Area */}
                {selectedTab === 'all' ? (
                     <FlatList
                        data={allClubs}
                        renderItem={({ item }) => (
                            <ClubCard club={item} onPress={handleClubPress} /> 
                        )}
                        keyExtractor={item => item.id}
                        ListEmptyComponent={renderListEmpty}
                        contentContainerStyle={styles.listContentContainer}
                     />
                ) : (
                    <FlatList
                        data={yourClubs}
                        renderItem={({ item }) => (
                            <ClubCard
                                club={item}
                                onPress={handleClubPress}
                                onDelete={() => handleDeleteClub(item.id)}
                            />
                        )}
                        keyExtractor={item => item.id}
                        ListHeaderComponent={() => (
                            <TouchableOpacity style={styles.createButton} onPress={handleCreateClubPress}>
                                <Ionicons name="add-circle-outline" size={22} color="#FFF" />
                                <Text style={styles.createButtonText}>Create New Club</Text>
                            </TouchableOpacity>
                        )}
                        ListEmptyComponent={renderListEmpty}
                        contentContainerStyle={styles.listContentContainer}
                     />
                )}
            </View>

            <CreateClubModal
                visible={isModalVisible}
                onClose={handleModalClose}
                onSubmit={handleModalSubmit}
            />
        </SafeAreaView>
    );
};

// Styles remain largely the same, ensure they match previous version
const DARK = '#1F0B3A';
const CARD_BG = '#2A1A4B';
const ACCENT = '#6372FF';
const ACCENT_LIGHT = '#8A94FF';

const styles = StyleSheet.create({
    safeArea: { flex: 1, backgroundColor: DARK },
    container: { flex: 1 }, 
    headerTitle: {
        color: '#FFF',
        fontSize: 24,
        fontWeight: 'bold',
        textAlign: 'center',
        marginTop: 20,
        marginBottom: 20,
        paddingHorizontal: 24,
    },
    segmentContainer: {
        flexDirection: 'row',
        backgroundColor: CARD_BG,
        borderRadius: 8,
        marginHorizontal: 24,
        overflow: 'hidden',
        marginBottom: 20,
    },
    segmentButton: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 12,
        gap: 6,
    },
    segmentButtonActive: { backgroundColor: ACCENT },
    segmentText: { color: '#AAA', fontWeight: '600' },
    segmentTextActive: { color: '#FFF' },
    listContentContainer: {
        paddingBottom: 20,
    },
     placeholderViewEmptyList: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: '20%',
        padding: 20,
    },
    placeholderText: { marginTop: 15, color: '#AAA', fontSize: 18, textAlign: 'center' },
    createButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: ACCENT_LIGHT,
        marginHorizontal: 24,
        paddingVertical: 14,
        borderRadius: 8,
        gap: 8,
        marginBottom: 20,
    },
    createButtonText: { color: '#FFF', fontSize: 16, fontWeight: '600' },
});

export default ClubScreen; 