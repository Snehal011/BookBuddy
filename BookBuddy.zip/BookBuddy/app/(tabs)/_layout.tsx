import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
                tabBarActiveTintColor: '#6372FF',
                tabBarInactiveTintColor: '#888',
                tabBarStyle: {
                    backgroundColor: '#1F0B3A',
                    borderTopColor: '#2A1A4B',
                    height: 70,
                },
                tabBarLabelStyle: {
                    fontSize: 12,
                    fontWeight: '500',
                },
                tabBarItemStyle: {
                    paddingTop: 8,
                    paddingBottom: 4,
                },
        headerShown: false,
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
                    tabBarIcon: ({ color }) => (
                        <Ionicons name="home-outline" size={24} color={color} />
                    ),
                }}
            />
            <Tabs.Screen
                name="Discover"
                options={{
                    title: 'Discover',
                    tabBarIcon: ({ color }) => (
                        <Ionicons name="search-outline" size={24} color={color} />
                    ),
                }}
            />
            <Tabs.Screen
                name="Club"
                options={{
                    title: 'Club',
                    tabBarIcon: ({ color }) => (
                        <Ionicons name="people-outline" size={24} color={color} />
                    ),
        }}
      />
      <Tabs.Screen
                name="Profile"
        options={{
                    title: 'Profile',
                    tabBarIcon: ({ color }) => (
                        <Ionicons name="person-outline" size={24} color={color} />
                    ),
        }}
      />
    </Tabs>
  );
}
